# TÜV Rheinland Oman - Certificate Verification Portal

A professional certificate verification portal for TÜV Rheinland Oman with admin dashboard for managing certificates.

## 🌐 Live Demo

**Website URL:** https://amkdd5r5sxgd4.ok.kimi.link

---

## ✨ Features

### 🔍 Certificate Verification
- Search certificates by certificate number
- Real-time validity check (Valid/Expired status)
- Display Name, Qualification, and Company
- Green/Red status indicators

### 🔐 Admin Dashboard
- Add new certificates
- Edit existing certificates
- Delete certificates
- Export certificates to JSON
- Import certificates from JSON
- Password protected (default: `tuvadmin2024`)

---

## 🚀 How to Host on GitHub Pages (Free)

### Step 1: Create GitHub Repository
1. Go to [GitHub](https://github.com) and create a new repository
2. Name it `tuv-certificate-verification`
3. Make it Public

### Step 2: Upload Files
Upload these files from the `dist` folder to your repository:
- `index.html`
- `assets/` (folder)
- `certificates.json`
- `tuv-logo.jpg`

### Step 3: Enable GitHub Pages
1. Go to repository **Settings**
2. Click **Pages** in the left sidebar
3. Under **Source**, select **Deploy from a branch**
4. Select **main** branch and **/(root)** folder
5. Click **Save**

Your site will be live at: `https://yourusername.github.io/tuv-certificate-verification`

---

## 📋 How to Add New Certificates

### Method 1: Using Admin Dashboard (Recommended)
1. Visit your live website
2. Click **Admin** button in top right
3. Enter password: `tuvadmin2024`
4. Click **Add Certificate** button
5. Fill in the details and save
6. Click **Export JSON** to download updated file
7. Replace `certificates.json` in your GitHub repository

### Method 2: Direct JSON Edit
1. Download `certificates.json` from your repository
2. Add new certificate entry:
```json
{
  "id": "TRO-OP-26-0018",
  "certificateNumber": "TRO-OP-26-0018",
  "name": "EMPLOYEE NAME",
  "qualification": "Qualification Name",
  "company": "Company Name",
  "validTill": "03.01.2028",
  "issueDate": "04.01.2026",
  "employeeNumber": "12345678"
}
```
3. Upload updated file to GitHub

---

## 📁 Project Structure

```
├── index.html          # Main HTML file
├── assets/             # CSS and JS files
│   ├── index-xxx.css
│   └── index-xxx.js
├── certificates.json   # Certificate data
├── tuv-logo.jpg        # TUV Logo
└── README.md           # This file
```

---

## 🔒 Admin Password

Default password: `tuvadmin2024`

To change the password, edit `src/App.tsx`:
```typescript
const ADMIN_PASSWORD = 'your-new-password'
```

Then rebuild and redeploy.

---

## 📝 Certificate Data Format

```json
{
  "id": "TRO-OP-26-0001",
  "certificateNumber": "TRO-OP-26-0001",
  "name": "Employee Full Name",
  "qualification": "Qualification Name",
  "company": "Company Name",
  "validTill": "DD.MM.YYYY",
  "issueDate": "DD.MM.YYYY",
  "employeeNumber": "12345678"
}
```

---

## 🛠️ Development (Optional)

To modify the code:

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

---

## 📞 Support

For issues or questions, contact TÜV Rheinland Oman.

---

© 2026 TÜV Rheinland Oman. All rights reserved.
