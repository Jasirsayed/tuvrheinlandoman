import { useState, useEffect } from 'react'
import { Search, CheckCircle, XCircle, Calendar, User, Building2, Award, Shield, Plus, Trash2, Edit, Download, Upload, LogOut, Lock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'

import { Alert, AlertDescription } from '@/components/ui/alert'
import './App.css'

interface Certificate {
  id: string
  certificateNumber: string
  name: string
  qualification: string
  company: string
  validTill: string
  issueDate: string
  employeeNumber: string
}

const ADMIN_PASSWORD = 'tuvadmin2024'

function App() {
  // State
  const [certificates, setCertificates] = useState<Certificate[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResult, setSearchResult] = useState<Certificate | null>(null)
  const [isSearching, setIsSearching] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const [showAdminLogin, setShowAdminLogin] = useState(false)
  const [adminPassword, setAdminPassword] = useState('')
  const [loginError, setLoginError] = useState('')
  
  // Admin form state
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [editingCert, setEditingCert] = useState<Certificate | null>(null)
  const [formData, setFormData] = useState<Partial<Certificate>>({
    certificateNumber: '',
    name: '',
    qualification: '',
    company: '',
    validTill: '',
    issueDate: '',
    employeeNumber: ''
  })

  // Load certificates from localStorage or JSON file
  useEffect(() => {
    const loadCertificates = async () => {
      // First try localStorage
      const saved = localStorage.getItem('tuv_certificates')
      if (saved) {
        setCertificates(JSON.parse(saved))
      } else {
        // Load from JSON file
        try {
          const response = await fetch('/certificates.json')
          const data = await response.json()
          setCertificates(data)
          localStorage.setItem('tuv_certificates', JSON.stringify(data))
        } catch (error) {
          console.error('Failed to load certificates:', error)
        }
      }
    }
    loadCertificates()
  }, [])

  // Save to localStorage whenever certificates change
  useEffect(() => {
    if (certificates.length > 0) {
      localStorage.setItem('tuv_certificates', JSON.stringify(certificates))
    }
  }, [certificates])

  // Check if certificate is valid
  const isCertificateValid = (validTill: string): boolean => {
    if (!validTill) return false
    const parts = validTill.split('.')
    if (parts.length !== 3) return false
    
    const day = parseInt(parts[0])
    const month = parseInt(parts[1]) - 1
    const year = parseInt(parts[2])
    
    const expiryDate = new Date(year, month, day)
    const today = new Date()
    
    return expiryDate >= today
  }

  // Search certificate
  const handleSearch = () => {
    if (!searchQuery.trim()) return
    
    setIsSearching(true)
    const query = searchQuery.trim().toUpperCase()
    
    const result = certificates.find(cert => 
      cert.certificateNumber.toUpperCase() === query
    )
    
    setSearchResult(result || null)
    setIsSearching(false)
  }

  // Handle Enter key
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch()
    }
  }

  // Admin login
  const handleAdminLogin = () => {
    if (adminPassword === ADMIN_PASSWORD) {
      setIsAdmin(true)
      setShowAdminLogin(false)
      setAdminPassword('')
      setLoginError('')
    } else {
      setLoginError('Invalid password')
    }
  }

  // Add/Edit certificate
  const handleSaveCertificate = () => {
    if (!formData.certificateNumber || !formData.name) {
      alert('Certificate Number and Name are required')
      return
    }

    if (editingCert) {
      // Update existing
      setCertificates(prev => prev.map(cert => 
        cert.id === editingCert.id ? { ...cert, ...formData } as Certificate : cert
      ))
    } else {
      // Add new
      const newCert: Certificate = {
        id: formData.certificateNumber!,
        certificateNumber: formData.certificateNumber!,
        name: formData.name || '',
        qualification: formData.qualification || '',
        company: formData.company || '',
        validTill: formData.validTill || '',
        issueDate: formData.issueDate || '',
        employeeNumber: formData.employeeNumber || ''
      }
      setCertificates(prev => [...prev, newCert])
    }

    setShowAddDialog(false)
    setEditingCert(null)
    setFormData({
      certificateNumber: '',
      name: '',
      qualification: '',
      company: '',
      validTill: '',
      issueDate: '',
      employeeNumber: ''
    })
  }

  // Delete certificate
  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this certificate?')) {
      setCertificates(prev => prev.filter(cert => cert.id !== id))
    }
  }

  // Edit certificate
  const handleEdit = (cert: Certificate) => {
    setEditingCert(cert)
    setFormData({ ...cert })
    setShowAddDialog(true)
  }

  // Export certificates to JSON
  const handleExport = () => {
    const dataStr = JSON.stringify(certificates, null, 2)
    const blob = new Blob([dataStr], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'certificates.json'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  // Import certificates from JSON
  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string)
        if (Array.isArray(data)) {
          setCertificates(data)
          alert('Certificates imported successfully!')
        } else {
          alert('Invalid JSON format')
        }
      } catch (error) {
        alert('Error parsing JSON file')
      }
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img 
                src="/tuv-logo.jpg" 
                alt="TÜV Rheinland Oman" 
                className="h-14 object-contain"
              />
              <div>
                <h1 className="text-xl font-bold text-slate-800">Certificate Verification</h1>
                <p className="text-sm text-slate-500">TÜV Rheinland Oman</p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => isAdmin ? setIsAdmin(false) : setShowAdminLogin(true)}
              className="text-slate-500"
            >
              {isAdmin ? (
                <><LogOut className="w-4 h-4 mr-2" /> Exit Admin</>
              ) : (
                <><Lock className="w-4 h-4 mr-2" /> Admin</>
              )}
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {!isAdmin ? (
          // Verification View
          <>
            {/* Search Section */}
            <Card className="mb-8 shadow-lg border-0">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-t-lg">
                <CardTitle className="text-xl flex items-center gap-2">
                  <Search className="w-5 h-5" />
                  Verify Certificate
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <Input
                      type="text"
                      placeholder="Enter Certificate Number (e.g., TRO-OP-26-0001)"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      onKeyPress={handleKeyPress}
                      className="h-12 text-lg"
                    />
                  </div>
                  <Button 
                    onClick={handleSearch}
                    className="h-12 px-8 bg-blue-600 hover:bg-blue-700"
                    disabled={isSearching}
                  >
                    <Search className="w-5 h-5 mr-2" />
                    Search
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Search Result */}
            {searchResult && (
              <Card className="mb-8 shadow-xl border-0 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
                <CardHeader className={`${isCertificateValid(searchResult.validTill) ? 'bg-green-600' : 'bg-red-600'} text-white`}>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl flex items-center gap-2">
                      {isCertificateValid(searchResult.validTill) ? (
                        <><CheckCircle className="w-6 h-6" /> Certificate Valid</>
                      ) : (
                        <><XCircle className="w-6 h-6" /> Certificate Expired</>
                      )}
                    </CardTitle>
                    <Badge 
                      variant="secondary" 
                      className={`text-sm px-3 py-1 ${isCertificateValid(searchResult.validTill) ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}
                    >
                      {isCertificateValid(searchResult.validTill) ? 'VALID' : 'EXPIRED'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid gap-4">
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 text-slate-500 mb-1">
                        <Award className="w-4 h-4" />
                        <span className="text-sm">Certificate Number</span>
                      </div>
                      <p className="text-lg font-semibold text-slate-800">{searchResult.certificateNumber}</p>
                    </div>
                    
                    <div className="bg-slate-50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 text-slate-500 mb-1">
                        <User className="w-4 h-4" />
                        <span className="text-sm">Name</span>
                      </div>
                      <p className="text-lg font-semibold text-slate-800">{searchResult.name}</p>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 text-slate-500 mb-1">
                        <Award className="w-4 h-4" />
                        <span className="text-sm">Qualification</span>
                      </div>
                      <p className="text-lg font-semibold text-slate-800">{searchResult.qualification}</p>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-lg">
                      <div className="flex items-center gap-2 text-slate-500 mb-1">
                        <Building2 className="w-4 h-4" />
                        <span className="text-sm">Company</span>
                      </div>
                      <p className="text-lg font-semibold text-slate-800">{searchResult.company}</p>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="bg-slate-50 p-4 rounded-lg">
                        <div className="flex items-center gap-2 text-slate-500 mb-1">
                          <Calendar className="w-4 h-4" />
                          <span className="text-sm">Issue Date</span>
                        </div>
                        <p className="text-lg font-semibold text-slate-800">{searchResult.issueDate}</p>
                      </div>
                      
                      <div className={`p-4 rounded-lg ${isCertificateValid(searchResult.validTill) ? 'bg-green-50' : 'bg-red-50'}`}>
                        <div className={`flex items-center gap-2 mb-1 ${isCertificateValid(searchResult.validTill) ? 'text-green-600' : 'text-red-600'}`}>
                          <Calendar className="w-4 h-4" />
                          <span className="text-sm">Valid Until</span>
                        </div>
                        <p className={`text-lg font-semibold ${isCertificateValid(searchResult.validTill) ? 'text-green-700' : 'text-red-700'}`}>
                          {searchResult.validTill}
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* No Result */}
            {searchResult === null && searchQuery && !isSearching && (
              <Card className="mb-8 shadow-lg border-0">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-slate-400" />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-700 mb-2">Certificate Not Found</h3>
                  <p className="text-slate-500">
                    No certificate found with number: <strong>{searchQuery}</strong>
                  </p>
                </CardContent>
              </Card>
            )}

            {/* Instructions */}
            <Card className="shadow-md border-0 bg-white/80 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-lg text-slate-700 flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  How to Verify
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 pt-0">
                <div className="grid sm:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <Search className="w-6 h-6 text-blue-600" />
                    </div>
                    <h4 className="font-semibold text-slate-700 mb-1">Enter Number</h4>
                    <p className="text-sm text-slate-500">Type the certificate number in the search box</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <CheckCircle className="w-6 h-6 text-blue-600" />
                    </div>
                    <h4 className="font-semibold text-slate-700 mb-1">Check Status</h4>
                    <p className="text-sm text-slate-500">View if certificate is Valid or Expired</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <Award className="w-6 h-6 text-blue-600" />
                    </div>
                    <h4 className="font-semibold text-slate-700 mb-1">View Details</h4>
                    <p className="text-sm text-slate-500">See Name, Qualification & Company</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        ) : (
          // Admin View
          <>
            <Card className="mb-6 shadow-lg border-0">
              <CardHeader className="bg-gradient-to-r from-slate-700 to-slate-800 text-white rounded-t-lg">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <Shield className="w-5 h-5" />
                    Admin Dashboard
                  </CardTitle>
                  <div className="flex gap-2">
                    <Button 
                      variant="secondary" 
                      size="sm"
                      onClick={handleExport}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Export JSON
                    </Button>
                    <Label className="cursor-pointer">
                      <Input 
                        type="file" 
                        accept=".json" 
                        className="hidden" 
                        onChange={handleImport}
                      />
                      <div className="flex items-center px-3 py-2 bg-secondary text-secondary-foreground text-sm font-medium rounded-md hover:bg-secondary/80">
                        <Upload className="w-4 h-4 mr-2" />
                        Import JSON
                      </div>
                    </Label>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <p className="text-slate-600">
                    Total Certificates: <strong>{certificates.length}</strong>
                  </p>
                  <Button onClick={() => {
                    setEditingCert(null)
                    setFormData({
                      certificateNumber: '',
                      name: '',
                      qualification: '',
                      company: '',
                      validTill: '',
                      issueDate: '',
                      employeeNumber: ''
                    })
                    setShowAddDialog(true)
                  }}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Certificate
                  </Button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-2 text-sm font-semibold text-slate-700">Certificate #</th>
                        <th className="text-left py-3 px-2 text-sm font-semibold text-slate-700">Name</th>
                        <th className="text-left py-3 px-2 text-sm font-semibold text-slate-700">Qualification</th>
                        <th className="text-left py-3 px-2 text-sm font-semibold text-slate-700">Company</th>
                        <th className="text-left py-3 px-2 text-sm font-semibold text-slate-700">Valid Till</th>
                        <th className="text-left py-3 px-2 text-sm font-semibold text-slate-700">Status</th>
                        <th className="text-left py-3 px-2 text-sm font-semibold text-slate-700">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {certificates.map((cert) => (
                        <tr key={cert.id} className="border-b hover:bg-slate-50">
                          <td className="py-3 px-2 text-sm">{cert.certificateNumber}</td>
                          <td className="py-3 px-2 text-sm">{cert.name}</td>
                          <td className="py-3 px-2 text-sm">{cert.qualification}</td>
                          <td className="py-3 px-2 text-sm">{cert.company}</td>
                          <td className="py-3 px-2 text-sm">{cert.validTill}</td>
                          <td className="py-3 px-2">
                            <Badge className={isCertificateValid(cert.validTill) ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                              {isCertificateValid(cert.validTill) ? 'Valid' : 'Expired'}
                            </Badge>
                          </td>
                          <td className="py-3 px-2">
                            <div className="flex gap-1">
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleEdit(cert)}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => handleDelete(cert.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {certificates.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-slate-500">No certificates found. Add your first certificate.</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Alert className="bg-blue-50 border-blue-200">
              <AlertDescription className="text-blue-800">
                <strong>GitHub Hosting Instructions:</strong> Click "Export JSON" to download the certificates file. 
                Replace the <code>certificates.json</code> file in your GitHub repository and commit the changes.
              </AlertDescription>
            </Alert>
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-6 mt-12">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <p className="text-slate-400 text-sm">
            © {new Date().getFullYear()} TÜV Rheinland Oman. All rights reserved.
          </p>
          <p className="text-slate-500 text-xs mt-2">
            This portal is for verification purposes only.
          </p>
        </div>
      </footer>

      {/* Admin Login Dialog */}
      <Dialog open={showAdminLogin} onOpenChange={setShowAdminLogin}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Admin Login
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={adminPassword}
              onChange={(e) => setAdminPassword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAdminLogin()}
              placeholder="Enter admin password"
              className="mt-2"
            />
            {loginError && (
              <p className="text-red-500 text-sm mt-2">{loginError}</p>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAdminLogin(false)}>Cancel</Button>
            <Button onClick={handleAdminLogin}>Login</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add/Edit Certificate Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingCert ? 'Edit Certificate' : 'Add New Certificate'}
            </DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div>
              <Label htmlFor="certNumber">Certificate Number *</Label>
              <Input
                id="certNumber"
                value={formData.certificateNumber}
                onChange={(e) => setFormData({...formData, certificateNumber: e.target.value})}
                placeholder="e.g., TRO-OP-26-0001"
              />
            </div>
            <div>
              <Label htmlFor="name">Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                placeholder="Full Name"
              />
            </div>
            <div>
              <Label htmlFor="qualification">Qualification</Label>
              <Input
                id="qualification"
                value={formData.qualification}
                onChange={(e) => setFormData({...formData, qualification: e.target.value})}
                placeholder="e.g., Basic Rigger Assessment"
              />
            </div>
            <div>
              <Label htmlFor="company">Company</Label>
              <Input
                id="company"
                value={formData.company}
                onChange={(e) => setFormData({...formData, company: e.target.value})}
                placeholder="Company Name"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="issueDate">Issue Date</Label>
                <Input
                  id="issueDate"
                  value={formData.issueDate}
                  onChange={(e) => setFormData({...formData, issueDate: e.target.value})}
                  placeholder="DD.MM.YYYY"
                />
              </div>
              <div>
                <Label htmlFor="validTill">Valid Till</Label>
                <Input
                  id="validTill"
                  value={formData.validTill}
                  onChange={(e) => setFormData({...formData, validTill: e.target.value})}
                  placeholder="DD.MM.YYYY"
                />
              </div>
            </div>
            <div>
              <Label htmlFor="empNumber">Employee Number</Label>
              <Input
                id="empNumber"
                value={formData.employeeNumber}
                onChange={(e) => setFormData({...formData, employeeNumber: e.target.value})}
                placeholder="Employee ID"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
            <Button onClick={handleSaveCertificate}>
              {editingCert ? 'Update' : 'Add'} Certificate
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default App
